import pyautogui
import keyboard
import random
import time

running = False
clicking = False
last_click_time = 0
double_click_delay = 0.3

def toggle_clicking():
    global clicking
    clicking = not clicking
    if clicking:
        print("AutoClicking started... (Double left-click to start, right-click to stop)")
    else:
        print("AutoClicking stopped.")

print("Program is running... Double left-click to start, right-click to stop.")

while True:
    if keyboard.is_pressed("left"):
        current_time = time.time()
        if current_time - last_click_time <= double_click_delay:
            if not clicking:
                toggle_clicking()
        last_click_time = current_time
        time.sleep(0.2)

    if keyboard.is_pressed("right"):
        if clicking:
            toggle_clicking()
        time.sleep(0.2)

    if clicking:
        interval = random.uniform(0.01, 0.04)
        pyautogui.click()
        time.sleep(interval)
