# AutoClick Bot

A simple Python-based autoclicker.

## 🚀 Features
- Start clicking with **double left-click**
- Stop clicking with **right-click**
- Random interval between 0.01s - 0.04s (≈120+ clicks / 5 sec)

## 📦 Installation
```bash
pip install -r requirements.txt
```

## ▶️ Run
```bash
python autoclick.py
```

## 📌 Note
Use responsibly ⚠️
